[![build](https://github.com/kirin123kirin/cdiffer/actions/workflows/build.yml/badge.svg?branch=master)](https://github.com/kirin123kirin/cdiffer/actions/workflows/build.yml)
